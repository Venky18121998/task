package com.userservice;

import com.userpojo.UserPojo;

public interface UserService {
	
	public UserPojo saveUserDetails(UserPojo userPojo);

}
